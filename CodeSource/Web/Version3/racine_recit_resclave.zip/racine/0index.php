<html>
<body>
<?php
echo 'PHP '.phpversion().' pour slave-narratives fonctionnel.';
?>
</body>
</html>
